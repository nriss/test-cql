# ans.fhir.fr.test-cql#0.1.0: POC CQL - ROR(fr)

## Pages

* [Accueil](index.md)
* [02 — ROR](cas-usage-02-ror.md)
* [Résumé des artefacts](artifacts.md)
* [01 — Exemple générique](cas-usage-01-generique.md)
* [Historique des versions](change-log.md)

## Resources

### ImplementationGuides

* [POC CQL - ROR](ImplementationGuide-ans.fhir.fr.test-cql.md)

### Libraries

* [Hello CQL — exemple générique](Library-HelloCQL.md)

### Measures

* [Proportion de patients âgés de 65 ans et plus](Measure-Patients65Plus.md)

### Examples

* [pat-bernard (Patient)](Patient-pat-bernard.md)
* [pat-dubois (Patient)](Patient-pat-dubois.md)
* [pat-martin (Patient)](Patient-pat-martin.md)
* [pat-petit (Patient)](Patient-pat-petit.md)
* [pat-thomas (Patient)](Patient-pat-thomas.md)
