# ans.fhir.fr.test-cql#0.1.0: POC CQL - ROR(en)

## Pages

* [Accueil](index.md)
* [03 — ROR sans CQL](cas-usage-03-ror-regle-01-recherche-fhir.md)
* [02 — ROR](cas-usage-02-ror.md)
* [Artifacts Summary](artifacts.md)
* [01 — Exemple générique](cas-usage-01-generique.md)
* [Historique des versions](change-log.md)

## Resources

### ImplementationGuides

* [POC CQL - ROR](ImplementationGuide-ans.fhir.fr.test-cql.md)

### Libraries

* [Hello CQL — exemple générique](Library-HelloCQL.md)
* [Organization avec le nom Urgence — Règle #1 ROR](Library-OrganizationNomUrgence.md)

### Measures

* [Organization non conformes à la règle du nom Urgence](Measure-OrganizationsNonConformesNomUrgence.md)
* [Proportion de patients âgés de 65 ans et plus](Measure-Patients65Plus.md)

### Examples

* [hs-ch-exemple-urgences (HealthcareService)](HealthcareService-hs-ch-exemple-urgences.md)
* [hs-clinique-exemple-urgences (HealthcareService)](HealthcareService-hs-clinique-exemple-urgences.md)
* [hs-service-urgences-pediatriques (HealthcareService)](HealthcareService-hs-service-urgences-pediatriques.md)
* [CH Exemple (Organization)](Organization-org-ch-exemple.md)
* [Clinique Exemple (Organization)](Organization-org-clinique-exemple.md)
* [Service des Urgences du CH Exemple (Organization)](Organization-org-service-urgences.md)
* [pat-bernard (Patient)](Patient-pat-bernard.md)
* [pat-dubois (Patient)](Patient-pat-dubois.md)
* [pat-martin (Patient)](Patient-pat-martin.md)
* [pat-petit (Patient)](Patient-pat-petit.md)
* [pat-thomas (Patient)](Patient-pat-thomas.md)
